import type { Candle } from '@/hooks/use-binance-market';

export type DivergenceKind = 'pressure' | 'direction';
export type DivergenceType = 'bullish' | 'bearish';

export type Divergence = {
  type: DivergenceType;
  study: DivergenceKind;
  fromTime: number;
  toTime: number;
  priceFrom: number;
  priceTo: number;
  studyFrom: number;
  studyTo: number;
};

export type VolumeProfileNode = {
  price: number;
  volume: number;
  isPoc: boolean;
};

function studyValue(candle: Candle, study: DivergenceKind) {
  return study === 'pressure'
    ? candle.delta
    : candle.directionBias || (candle.close >= candle.open ? 1 : -1);
}

function cumulativeStudy(candles: Candle[], study: DivergenceKind) {
  let running = 0;
  return candles.map((candle) => {
    running += studyValue(candle, study);
    return running;
  });
}

function isPivotLow(values: number[], index: number) {
  return values[index] <= values[index - 1] && values[index] <= values[index + 1];
}

function isPivotHigh(values: number[], index: number) {
  return values[index] >= values[index - 1] && values[index] >= values[index + 1];
}

export function detectDivergences(candles: Candle[], study: DivergenceKind): Divergence[] {
  if (candles.length < 8) return [];

  const recent = candles.slice(-80);
  const pricesLow = recent.map((candle) => candle.low);
  const pricesHigh = recent.map((candle) => candle.high);
  const flow = cumulativeStudy(recent, study);
  const results: Divergence[] = [];
  const lows = recent.map((_, index) => index).filter((index) => index > 0 && index < recent.length - 1 && isPivotLow(pricesLow, index));
  const highs = recent.map((_, index) => index).filter((index) => index > 0 && index < recent.length - 1 && isPivotHigh(pricesHigh, index));

  for (let index = 1; index < lows.length; index += 1) {
    const from = lows[index - 1];
    const to = lows[index];
    if (pricesLow[to] < pricesLow[from] && flow[to] > flow[from]) {
      results.push({ type: 'bullish', study, fromTime: recent[from].time, toTime: recent[to].time, priceFrom: pricesLow[from], priceTo: pricesLow[to], studyFrom: flow[from], studyTo: flow[to] });
    }
  }

  for (let index = 1; index < highs.length; index += 1) {
    const from = highs[index - 1];
    const to = highs[index];
    if (pricesHigh[to] > pricesHigh[from] && flow[to] < flow[from]) {
      results.push({ type: 'bearish', study, fromTime: recent[from].time, toTime: recent[to].time, priceFrom: pricesHigh[from], priceTo: pricesHigh[to], studyFrom: flow[from], studyTo: flow[to] });
    }
  }

  return results.slice(-4);
}

export function buildVolumeProfile(candles: Candle[], binCount = 14): VolumeProfileNode[] {
  if (!candles.length) return [];
  const min = Math.min(...candles.map((candle) => candle.low));
  const max = Math.max(...candles.map((candle) => candle.high));
  const span = max - min || 1;
  const nodes = Array.from({ length: binCount }, (_, index) => ({
    price: min + ((index + 0.5) / binCount) * span,
    volume: 0,
    isPoc: false,
  }));

  candles.forEach((candle) => {
    const index = Math.max(0, Math.min(binCount - 1, Math.floor(((candle.close - min) / span) * binCount)));
    nodes[index].volume += candle.volume;
  });

  const poc = Math.max(...nodes.map((node) => node.volume));
  return nodes.map((node) => ({ ...node, isPoc: node.volume === poc }));
}